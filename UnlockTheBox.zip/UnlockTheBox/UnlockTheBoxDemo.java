class UnlockTheBoxDemo {
	public static void main(String[] args) {
		UnlockTheBox unlockBox = new UnlockTheBox();
		unlockBox.setSize(400, 600);
		unlockBox.setVisible(true);
	}
}